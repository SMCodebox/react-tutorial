import React from 'react'

export const About = () => {
  return (
    <div className="container">
        <h1>About</h1>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Impedit architecto, perferendis neque, odit optio dolore ex sit qui aut porro eius alias minus minima dolor eaque dicta asperiores quos voluptas recusandae veritatis voluptates temporibus illum? Asperiores ab cumque repellat exercitationem recusandae tempore nostrum alias vero, inventore optio enim dolores quasi?</p>
    </div>
  )
}
